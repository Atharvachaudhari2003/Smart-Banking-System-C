#include<stdio.h>
#include<stdlib.h>

    struct user
    {
        int acc_no;
        char name[30];
        int balance;
        int pin;

    };


    //fun

    void delete_account()
{
    FILE *fp, *temp;
    struct user u;

    int acc, pin, found = 0;

    fp = fopen("bank.txt", "rb");
    temp = fopen("temp.txt", "wb");

    printf("Enter Account Number: ");
    scanf("%d", &acc);

    printf("Enter PIN: ");
    scanf("%d", &pin);

    while(fread(&u, sizeof(u), 1, fp))
    {
        if(u.acc_no == acc && u.pin == pin)
        {
            found = 1;
            printf("Account Deleted!\n");
        }
        else
        {
            fwrite(&u, sizeof(u), 1, temp);
        }
    }

    fclose(fp);
    fclose(temp);

    remove("bank.txt");
    rename("temp.txt", "bank.txt");

    if(found == 0)
    {
        printf("Account not found!\n");
    }
}




    void search_history()
    {
        FILE *fp;
        char ch;

        fp=fopen("history.txt","r");

        if(fp==NULL)
        {
            printf("\nNo History Found!");
            return;
        }

        while((ch= fgetc(fp))!=EOF)
        {
            printf("%c",ch);

        }

        fclose(fp);

    }


void search_account()
{
    FILE *fp;
    struct user u;
    int acc;
    int found=0;

    fp=fopen("bank.txt","rb");

    printf("Enter Account Number:-");
    scanf("%d",&acc);

    while(fread(&u,sizeof(u),1,fp))
    {
        if(u.acc_no==acc)
        {
            printf("\nName :-%s",u.name);
            printf("\nBalance:-%d",u.balance);
            printf("\nAcc_NO:-%d\n",u.acc_no);
            found=1;

        }
    }

    if(found==0)
    {
        printf("Account Not Found!\n");
    }
    fclose(fp);


}


void create_account()
{
   // printf("Create Account\n");
   struct user u;
   FILE *fp;
   fp= fopen("bank.txt","ab");

   if(fp==NULL)
   {
    printf("FILE ERROR\n");
    return;
   }

   printf("Enter Account NO:-");
   scanf("%d",&u.acc_no);

   printf("Enter Name:-");
   scanf("%s",u.name);

   printf("Entert Balance:-");
   scanf("%d",&u.balance);

   printf("Enter PIN:-");
   scanf("%d",&u.pin);

   fwrite(&u,sizeof(u),1,fp);

   fclose(fp);
   printf("\nAccount Created Successfully!\n");



}

void deposit()
{
   // printf("Deposit\n");
   FILE *fp,*temp;
   struct user u;

   int acc,pin,amount,found=0;
   fp=fopen("bank.txt","rb");
   temp=fopen("temp.txt","wb");

   if(fp == NULL || temp == NULL)
  {
    printf("File error!\n");
    return;
  }

   printf("Enter Account Number:-");
   scanf("%d",&acc);

   printf("Enter PIN:-");
   scanf("%d",&pin);

   printf("Enter the Deposit Ammount:-");
   scanf("%d",&amount);


   

   while(fread(&u,sizeof(u),1,fp))
   {
    if(u.acc_no==acc && u.pin==pin)
    {
        u.balance=u.balance+amount;
        found=1;
        printf("Amount Deposited Successfully!\n");

    }
    fwrite(&u,sizeof(u),1,temp);

   }
   fclose(fp);
   fclose(temp);
   remove("bank.txt");
   rename("temp.txt","bank.txt");

   if(found==0)
   {
       printf("Account not found or wrong PIN!\n");
   }

   FILE *log=fopen("history.txt","a");
   fprintf(log,"Account:-%d\nDeposit:-%d\n",acc,amount);
   fclose(log);




}

void withdraw()
{
    FILE *fp, *temp;
    struct user u;

    int acc, pin, amount, found = 0;

    fp = fopen("bank.txt", "rb");
    temp = fopen("temp.txt", "wb");


    if(fp == NULL || temp == NULL)
    {
    printf("File error!\n");
    return;
    }

    printf("Enter Account Number: ");
    scanf("%d", &acc);

    printf("Enter PIN: ");
    scanf("%d", &pin);

    printf("Enter amount to withdraw: ");
    scanf("%d", &amount);

    while(fread(&u, sizeof(u), 1, fp))
    {
        if(u.acc_no == acc && u.pin == pin)
        {
            if(u.balance >= amount)
            {
                u.balance -= amount;
                printf("Amount Withdrawn!\n");
            }
            else
            {
                printf("\nInsufficient Balance!\n");
            }
            found = 1;
        }

        fwrite(&u, sizeof(u), 1, temp);
    }

    fclose(fp);
    fclose(temp);

    remove("bank.txt");
    rename("temp.txt", "bank.txt");

    if(found == 0)
    {
        printf("Account not found or wrong PIN!\n");
    }

    FILE *log=fopen("history.txt","a");
    fprintf(log, "Acc:%d Withdraw:%d\n", acc, amount);
    fclose(log);



}

void check_balance()
{
   // printf("Check Balance\n");

    FILE *fp;
    struct user u;
    int acc,pin ,found=0;

    fp=fopen("bank.txt","rb");//read mode

    if(fp==NULL)
    {
        printf("File not found!\n");
        return;
    }

    printf("Enter the Account no:-");
    scanf("%d",&acc);

    printf("Enter PIN:-");
    scanf("%d",&pin);

    while (fread(&u, sizeof(u),1,fp))
    {
       if(u.acc_no==acc &&u.pin==pin)
       {
        printf("\nName:-%s",u.name);
        printf("\nBalance:-%d\n",u.balance);
        found=1;
        break;
       }
    }

    if(found==0)
    {
        printf("Account not found or wrong PIN!\n");
    }
    fclose(fp);
}

//function declaration

void create_account();
void deposit();
void withdraw();
void check_balance();
void delete_account();
void search_account();
void search_history();



  

    int main()
    {
        int choice;
        

        while (1)
        {
            printf("\n****** WELCOME TO SMART BANKING SYSTEM ******\n");
            printf("\n 1.Create Account");
            printf("\n 2.Deposite Money");
            printf("\n 3.Withdraw Money");
            printf("\n 4.Cheak Balance");
            printf("\n 5.Delete Account");
            printf("\n 6.Search Account");
            printf("\n 7.Search History");
            printf("\n 8.Exit\n");


            printf("\nEnter the choice code:-");
            scanf("%d",&choice);


        

        switch(choice)
        {
            case 1:create_account();
            break;
            
            case 2:deposit();
            break;

            case 3:withdraw();
            break;
            
            case 4:check_balance();
            break;

            case 5:delete_account();
            break;

            case 6:search_account();
            break;

            case 7:search_history();
            break;


            case 8:exit(0);

            default:
            printf("Invalid choice!\n");

        }
        
    }
    }

